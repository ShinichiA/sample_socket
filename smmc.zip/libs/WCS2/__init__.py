from config.config import *


class WCS2:
    def __init__(self):
        self._command_read = ""

    def __str__(self):
        return TYPE_WCS2

    def read(self):
        """"""

    def send(self):
        """"""
