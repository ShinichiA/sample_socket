from config.config import *


class DSD1:
    def __init__(self):
        self._command_read = ""

    def __str__(self):
        return TYPE_DSD1

    def read(self):
        """"""

    def send(self):
        """"""
