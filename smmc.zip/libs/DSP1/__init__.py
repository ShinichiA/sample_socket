from config.config import *


class DSP1:
    def __init__(self):
        self._command_read = ""

    def __str__(self):
        return TYPE_DSP1

    def read(self):
        """"""

    def send(self):
        """"""
