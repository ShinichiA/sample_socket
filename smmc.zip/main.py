import time
from config import config
from services import SMMC
from common import common

list_thread = dict()

if __name__ == "__main__":
    port_by_route = common.detect_device_by_hw()

    for key, value in port_by_route.items():
        list_thread[key] = SMMC(port=key, baudrate=9600, list_device=value)
        list_thread[key].start()

    time.sleep(2)

    while True:
        # detect add or release port
        port_by_route_new = common.detect_device_by_hw()
        if port_by_route_new.keys() != port_by_route.keys():
            for key, value in port_by_route.items():
                if key not in port_by_route_new.keys():
                    list_thread[key].kill_thread()
                    list_thread[key].join()
                    list_thread.pop(key)

            for key, value in port_by_route_new.items():
                if key not in port_by_route.keys():
                    list_thread[key] = SMMC(port=key, baudrate=9600, list_device=value)
                    list_thread[key].start()

        port_by_route = port_by_route_new.copy()

        time.sleep(2)
