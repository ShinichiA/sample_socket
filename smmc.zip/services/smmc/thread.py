import threading
import time
import serial
from config.config import *
from libs import DSP1, DSD1, WCS2, Log

log = Log(__name__)


class SMMC(threading.Thread):
    def __init__(self, port, baudrate, list_device):
        super().__init__()
        self._port = port
        self._baudrate = baudrate
        self._list_device = list_device
        self._list_device_object = list()
        self._keep_running = True
        self._ser = None

    def run(self):
        log.warn("Start thread %s" % self._port)

        if not self.open_serial():
            return False
        self.create_list_object_device()
        print(self._list_device_object)
        while self._keep_running:
            if len(self._list_device_object) == 0:
                time.sleep(20)
                continue

            for device_object in self._list_device_object:
                self.handle_device(device_object)
                log.info("This is thread %s" % self._port)
                time.sleep(5)

        log.warn("Release thread %s" % self._port)

    def kill_thread(self):
        self.close_serial()
        self._keep_running = False

    def open_serial(self):
        try:
            self._ser = serial.Serial(self._port, baudrate=self._baudrate, timeout=1)
            log.info(f"Opened serial port {self._port}")
            return True
        except Exception as e:
            log.error(str(e))
            self._ser = None
        return False

    def close_serial(self):
        try:
            self._ser.close()
            return True
        except Exception as e:
            log.error(str(e))
            self._ser = None
        return False

    def create_list_object_device(self):
        for device_type in self._list_device:
            device_object = DeviceFactory.create_device(device_type)
            if not device_object:
                continue
            self._list_device_object.append(device_object)

    @staticmethod
    def handle_device(device_type):
        if device_type == TYPE_DSD1:
            """"""

        if device_type == TYPE_DSP1:
            """"""

        if device_type == TYPE_WCS2:
            """"""


class DeviceFactory:
    @staticmethod
    def create_device(device_type):
        if device_type == TYPE_DSD1:
            return DSD1()
        elif device_type == TYPE_DSP1:
            return DSP1()
        elif device_type == TYPE_WCS2:
            return WCS2()
        else:
            return None
