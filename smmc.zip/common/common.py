import serial.tools.list_ports
from config import config


def detect_device_by_hw():
    port_by_route = dict()
    ports = serial.tools.list_ports.comports()
    for target_serial in config.list_serial:
        for port in ports:
            if '/dev/ttyUSB' not in port.device:
                continue
            if target_serial in port.hwid:
                port_by_route[port.device] = config.list_serial[target_serial]

    return port_by_route
